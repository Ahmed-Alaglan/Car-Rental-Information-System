package com.mycompany.miniproject;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class CarControllerServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String plate = request.getParameter("plate_number");
        String model = request.getParameter("car_model");
        String rate = request.getParameter("rental_rate");
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            String url = "jdbc:ucanaccess://C:/EAD/CarRental.accdb";
            Connection con = DriverManager.getConnection(url);
            String sql = "INSERT INTO Car (PlateNumber, Model, Rate, Available) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, plate);
            ps.setString(2, model);
            ps.setString(3, rate);
            ps.setBoolean(4, true);
            ps.executeUpdate();
            con.close();
            response.sendRedirect("success.jsp");
        } catch (Exception e) {
            throw new ServletException("Error: " + e.getMessage());
        }
    }
}