package com.mycompany.miniproject;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;
public class ViewCarsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            String url = "jdbc:ucanaccess://C:/EAD/CarRental.accdb";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM Car");
            ArrayList<car> carList = new ArrayList<>();
            while (rs.next()) {
                car c = new car();
                c.setPlateNumber(rs.getString("PlateNumber"));
                c.setModel(rs.getString("Model"));
                c.setRate(rs.getDouble("Rate"));
                c.setAvailable(rs.getBoolean("Available"));
                carList.add(c);
            }
            con.close();
            request.setAttribute("carList", carList);
            RequestDispatcher rd = request.getRequestDispatcher("ViewCars.jsp");
            rd.forward(request, response);

        } catch (Exception e) {
            throw new ServletException("Error: " + e.getMessage());
        }
    }
}